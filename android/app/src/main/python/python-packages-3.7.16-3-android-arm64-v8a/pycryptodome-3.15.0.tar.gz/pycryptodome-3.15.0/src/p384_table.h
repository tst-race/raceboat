/* This file was automatically generated, do not edit */
#include "common.h"
extern const unsigned p384_n_tables;
extern const unsigned p384_window_size;
extern const unsigned p384_points_per_table;
extern const uint64_t p384_tables[77][32][2][6];

